import SwiftUI
import CoreLocation

struct ReportsView: View {
    @EnvironmentObject private var store: DataStore
    @EnvironmentObject private var location: LocationManager
    @State private var askName = false
    @State private var newName = ""
    @State private var tip: String?

    var body: some View {
        NavigationStack {
            List {
                placesSection
                eventsSection
            }
            .navigationTitle("报备")
            .alert("给这个地点起个名字", isPresented: $askName) {
                TextField("例如：家", text: $newName)
                Button("添加") {
                    confirmAdd()
                }
                Button("取消", role: .cancel) {
                    newName = ""
                }
            }
        }
        .alert("提示", isPresented: Binding(get: { tip != nil }, set: { if !$0 { tip = nil } })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(tip ?? "")
        }
    }

    private var placesSection: some View {
        Section {
            if store.places.isEmpty {
                Text("还没有常用地点。人在家或公司时，点下面的按钮添加。")
                    .font(.footnote)
                    .foregroundStyle(Color.secondary)
            }
            ForEach(store.places) { place in
                HStack {
                    Image(systemName: "mappin.circle.fill")
                        .foregroundStyle(Theme.limeDeep)
                    Text(place.name)
                    Spacer()
                    Text("\(Int(place.radius)) 米")
                        .font(.footnote)
                        .foregroundStyle(Color.secondary)
                }
            }
            .onDelete(perform: deletePlaces)
            Button {
                addCurrentPlace()
            } label: {
                Label("把当前位置添加为地点", systemImage: "plus.circle.fill")
            }
        } header: {
            Text("常用地点（到达/离开会自动报备）")
        }
    }

    private var eventsSection: some View {
        Section {
            if store.events.isEmpty {
                Text("暂无记录")
                    .font(.footnote)
                    .foregroundStyle(Color.secondary)
            }
            ForEach(store.events) { event in
                HStack {
                    Image(systemName: event.entered ? "arrow.down.circle.fill" : "arrow.up.circle.fill")
                        .foregroundStyle(event.entered ? Theme.limeDeep : Color.orange)
                    VStack(alignment: .leading) {
                        Text(event.entered ? "到达「\(event.placeName)」" : "离开「\(event.placeName)」")
                        Text(event.date.formatted(date: .abbreviated, time: .shortened))
                            .font(.caption)
                            .foregroundStyle(Color.secondary)
                    }
                }
            }
        } header: {
            Text("报备记录")
        }
    }

    private func addCurrentPlace() {
        if location.current == nil {
            tip = "还没拿到定位。请先在首页右上角「设置」里允许定位，稍等几秒再试。"
            return
        }
        if store.places.count >= 18 {
            tip = "地点太多了，先删几个吧。"
            return
        }
        newName = ""
        askName = true
    }

    private func confirmAdd() {
        let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        newName = ""
        guard let loc = location.current, !name.isEmpty else { return }
        let place = Place(name: name, latitude: loc.coordinate.latitude, longitude: loc.coordinate.longitude, radius: 150)
        store.places.append(place)
        location.monitor(place)
        if !location.hasAlways {
            tip = "已添加。想在后台自动报备，请到「设置 → 权限设置」把定位改为「始终允许」。"
        }
    }

    private func deletePlaces(at offsets: IndexSet) {
        for index in offsets {
            location.stopMonitoring(store.places[index])
        }
        store.places.remove(atOffsets: offsets)
    }
}
