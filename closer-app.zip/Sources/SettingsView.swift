import SwiftUI
import UIKit
import CoreLocation

struct SettingsView: View {
    @EnvironmentObject private var location: LocationManager
    @Environment(\.dismiss) private var dismiss
    @AppStorage("mapKind") private var mapKind = 0
    @AppStorage("togetherSince") private var togetherSince: Double = 0

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(spacing: 6) {
                        Image(systemName: "heart.fill")
                            .foregroundStyle(Color.red)
                        Text("在一起")
                            .font(.footnote)
                            .foregroundStyle(Color.secondary)
                        Text("\(days) 天")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                    }
                    .frame(maxWidth: .infinity)
                    DatePicker("纪念日", selection: anniversaryBinding, in: ...Date(), displayedComponents: .date)
                }

                Section("权限设置") {
                    HStack {
                        Text("定位")
                        Spacer()
                        Text(statusText)
                            .foregroundStyle(Color.secondary)
                    }
                    Button("允许定位") {
                        location.requestWhenInUse()
                    }
                    Button("改为「始终允许」（后台报备需要）") {
                        location.requestAlways()
                    }
                    Button("允许通知（到家/离开提醒）") {
                        location.requestNotifications()
                    }
                    Button("打开系统设置") {
                        openSystemSettings()
                    }
                }

                Section("地图设置") {
                    Picker("地图样式", selection: $mapKind) {
                        Text("标准").tag(0)
                        Text("卫星").tag(1)
                    }
                    .pickerStyle(.segmented)
                }

                Section("关于") {
                    HStack {
                        Text("版本")
                        Spacer()
                        Text("0.1（测试版）")
                            .foregroundStyle(Color.secondary)
                    }
                    Text("目前所有数据只保存在这台手机上。")
                        .font(.footnote)
                        .foregroundStyle(Color.secondary)
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") {
                        dismiss()
                    }
                }
            }
        }
    }

    private var anniversaryBinding: Binding<Date> {
        Binding(
            get: { togetherSince == 0 ? Date() : Date(timeIntervalSince1970: togetherSince) },
            set: { togetherSince = $0.timeIntervalSince1970 }
        )
    }

    private var days: Int {
        if togetherSince == 0 { return 0 }
        let start = Date(timeIntervalSince1970: togetherSince)
        let diff = Calendar.current.dateComponents([.day], from: start, to: Date()).day ?? 0
        return max(0, diff)
    }

    private var statusText: String {
        switch location.authorization {
        case .authorizedAlways: return "始终允许"
        case .authorizedWhenInUse: return "使用期间允许"
        case .denied: return "已拒绝"
        case .restricted: return "受限制"
        case .notDetermined: return "未选择"
        @unknown default: return "未知"
        }
    }

    private func openSystemSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
