import SwiftUI
import UIKit

struct MatchSheet: View {
    @EnvironmentObject private var store: DataStore
    @Environment(\.dismiss) private var dismiss
    @State private var editing = false
    @State private var input = ""
    @State private var message: String?
    @State private var showShare = false
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 14) {
            header
            featureCards
            Text("立即添加另一半")
                .font(.headline)
            partnerInput
            Text("我的匹配码")
                .font(.footnote)
                .foregroundStyle(Color.secondary)
            codeRow
            countdown
            Button {
                showShare = true
            } label: {
                Label("分享给另一半", systemImage: "square.and.arrow.up")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Theme.ink)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 10)
                    .background(Theme.lime, in: Capsule())
            }
            Spacer(minLength: 0)
        }
        .padding(16)
        .background(
            LinearGradient(colors: [Theme.sheetTop, Color.white], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
        )
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
        .sheet(isPresented: $showShare) {
            ActivityView(items: ["我的匹配码是 \(store.matchCode)，24 小时内有效。"])
        }
        .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(message ?? "")
        }
    }

    private var header: some View {
        HStack {
            Button {
                store.refreshCodeIfExpired()
            } label: {
                Label("刷新匹配状态", systemImage: "arrow.triangle.2.circlepath")
                    .font(.footnote)
                    .foregroundStyle(Theme.limeDeep)
            }
            Spacer()
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(Theme.ink)
            }
        }
    }

    private var featureCards: some View {
        TabView {
            featureCard(icon: "mappin.and.ellipse", title: "实时位置", text: "在地图上看到彼此")
            featureCard(icon: "bubble.left.and.bubble.right.fill", title: "自动报备", text: "到家、离开自动记录")
            featureCard(icon: "heart.fill", title: "在一起", text: "记录在一起的每一天")
        }
        .tabViewStyle(.page(indexDisplayMode: .always))
        .frame(height: 150)
    }

    private func featureCard(icon: String, title: String, text: String) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 34))
                .foregroundStyle(Theme.limeDeep)
            Text(title)
                .font(.headline)
            Text(text)
                .font(.caption)
                .foregroundStyle(Color.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .padding(.horizontal, 24)
        .padding(.bottom, 28)
    }

    private var partnerInput: some View {
        Group {
            if editing {
                HStack {
                    TextField("输入对方的 6 位匹配码", text: $input)
                        .keyboardType(.numberPad)
                        .focused($focused)
                    Button("确定") {
                        submit()
                    }
                    .fontWeight(.semibold)
                    .foregroundStyle(Theme.limeDeep)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(Color.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Theme.lime, lineWidth: 2))
                .onAppear {
                    focused = true
                }
            } else {
                Button {
                    editing = true
                } label: {
                    Text("点击输入对方匹配码")
                        .font(.subheadline)
                        .foregroundStyle(Theme.limeDeep)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(Color.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Theme.lime, lineWidth: 2))
                }
            }
        }
    }

    private var codeRow: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(spaced(store.matchCode))
                .font(.system(size: 34, weight: .heavy, design: .rounded))
                .foregroundStyle(Theme.ink)
            Button("复制") {
                UIPasteboard.general.string = store.matchCode
                message = "已复制匹配码"
            }
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(Theme.limeDeep)
        }
    }

    private var countdown: some View {
        TimelineView(.periodic(from: Date.now, by: 1)) { context in
            let remain = max(0, Int(store.matchExpiry.timeIntervalSince(context.date)))
            Text("匹配码 \(clock(remain)) 后失效，快去邀请另一半吧")
                .font(.caption)
                .foregroundStyle(Color.secondary)
        }
    }

    private func clock(_ seconds: Int) -> String {
        let h = seconds / 3600
        let m = (seconds % 3600) / 60
        let s = seconds % 60
        return String(format: "%02d:%02d:%02d", h, m, s)
    }

    private func spaced(_ code: String) -> String {
        guard code.count == 6 else { return code }
        return String(code.prefix(3)) + " " + String(code.suffix(3))
    }

    private func submit() {
        let code = input.filter { $0.isNumber }
        if code.count != 6 {
            message = "请输入 6 位数字匹配码"
            return
        }
        if code == store.matchCode {
            message = "这是你自己的匹配码哦"
            return
        }
        editing = false
        input = ""
        message = "已记下匹配码 \(code)。真正配对需要服务器，下一步接入后才会生效。"
    }
}
