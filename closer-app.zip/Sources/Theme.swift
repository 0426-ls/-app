import SwiftUI

enum Theme {
    static let lime = Color(red: 0.78, green: 0.94, blue: 0.22)
    static let limeDeep = Color(red: 0.42, green: 0.72, blue: 0.12)
    static let ink = Color(red: 0.17, green: 0.17, blue: 0.17)
    static let sheetTop = Color(red: 0.86, green: 0.98, blue: 0.66)
}
