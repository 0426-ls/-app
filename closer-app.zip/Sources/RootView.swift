import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("首页", systemImage: "house.fill") }
            ReportsView()
                .tabItem { Label("报备", systemImage: "bubble.left.and.bubble.right.fill") }
        }
        .tint(Theme.limeDeep)
    }
}
