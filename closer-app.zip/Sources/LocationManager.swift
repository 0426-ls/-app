import Foundation
import CoreLocation
import UserNotifications
import Combine

final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = LocationManager()

    private let manager = CLLocationManager()
    private weak var store: DataStore?

    @Published var authorization: CLAuthorizationStatus = .notDetermined
    @Published var current: CLLocation?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        manager.distanceFilter = 50
        authorization = manager.authorizationStatus
    }

    var hasAnyPermission: Bool {
        authorization == .authorizedAlways || authorization == .authorizedWhenInUse
    }

    var hasAlways: Bool {
        authorization == .authorizedAlways
    }

    func attach(store: DataStore) {
        self.store = store
        for place in store.places {
            monitor(place)
        }
        startIfAllowed()
    }

    func requestWhenInUse() {
        manager.requestWhenInUseAuthorization()
    }

    func requestAlways() {
        manager.requestAlwaysAuthorization()
    }

    func requestNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    func startIfAllowed() {
        if hasAnyPermission {
            manager.startUpdatingLocation()
        }
    }

    // MARK: - 地点监控（到达 / 离开）

    func monitor(_ place: Place) {
        guard CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) else { return }
        let radius = min(place.radius, manager.maximumRegionMonitoringDistance)
        let region = CLCircularRegion(center: place.coordinate, radius: radius, identifier: place.id.uuidString)
        region.notifyOnEntry = true
        region.notifyOnExit = true
        manager.startMonitoring(for: region)
    }

    func stopMonitoring(_ place: Place) {
        for region in manager.monitoredRegions where region.identifier == place.id.uuidString {
            manager.stopMonitoring(for: region)
        }
    }

    // MARK: - CLLocationManagerDelegate

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorization = manager.authorizationStatus
        startIfAllowed()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let last = locations.last {
            current = last
        }
    }

    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        handle(region: region, entered: true)
    }

    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        handle(region: region, entered: false)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // 暂时忽略定位错误
    }

    private func handle(region: CLRegion, entered: Bool) {
        guard let store = store,
              let place = store.places.first(where: { $0.id.uuidString == region.identifier }) else { return }
        store.addEvent(placeName: place.name, entered: entered)
        let body = entered ? "你到达了「\(place.name)」" : "你离开了「\(place.name)」"
        notify(title: "自动报备", body: body)
    }

    private func notify(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = UNNotificationSound.default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }
}
