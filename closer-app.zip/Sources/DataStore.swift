import Foundation
import CoreLocation
import Combine

struct Place: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var latitude: Double
    var longitude: Double
    var radius: Double

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct ReportEvent: Identifiable, Codable, Equatable {
    var id = UUID()
    var placeName: String
    var entered: Bool
    var date: Date
}

final class DataStore: ObservableObject {
    static let shared = DataStore()

    @Published var places: [Place] {
        didSet { Self.save(places, key: "places") }
    }
    @Published var events: [ReportEvent] {
        didSet { Self.save(events, key: "events") }
    }
    @Published var matchCode: String
    @Published var matchExpiry: Date

    private init() {
        let defaults = UserDefaults.standard
        places = Self.load([Place].self, key: "places") ?? []
        events = Self.load([ReportEvent].self, key: "events") ?? []
        if let code = defaults.string(forKey: "matchCode"),
           let expiry = defaults.object(forKey: "matchExpiry") as? Date,
           expiry > Date() {
            matchCode = code
            matchExpiry = expiry
        } else {
            let code = Self.makeCode()
            let expiry = Date().addingTimeInterval(24 * 3600)
            matchCode = code
            matchExpiry = expiry
            defaults.set(code, forKey: "matchCode")
            defaults.set(expiry, forKey: "matchExpiry")
        }
    }

    func refreshCodeIfExpired() {
        if matchExpiry <= Date() {
            regenerateCode()
        }
    }

    func regenerateCode() {
        matchCode = Self.makeCode()
        matchExpiry = Date().addingTimeInterval(24 * 3600)
        let defaults = UserDefaults.standard
        defaults.set(matchCode, forKey: "matchCode")
        defaults.set(matchExpiry, forKey: "matchExpiry")
    }

    func addEvent(placeName: String, entered: Bool) {
        events.insert(ReportEvent(placeName: placeName, entered: entered, date: Date()), at: 0)
        if events.count > 200 {
            events.removeLast(events.count - 200)
        }
    }

    private static func makeCode() -> String {
        String(format: "%06d", Int.random(in: 0...999_999))
    }

    private static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    private static func save<T: Encodable>(_ value: T, key: String) {
        if let data = try? JSONEncoder().encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
