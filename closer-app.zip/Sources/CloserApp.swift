import SwiftUI

@main
struct CloserApp: App {
    @StateObject private var store = DataStore.shared
    @StateObject private var location = LocationManager.shared

    init() {
        // 放在 init 里：即使 App 是被系统在后台唤醒（到达/离开地点），也能接住事件
        LocationManager.shared.attach(store: DataStore.shared)
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(location)
        }
    }
}
