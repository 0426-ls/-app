import SwiftUI
import MapKit

struct HomeView: View {
    @EnvironmentObject private var store: DataStore
    @EnvironmentObject private var location: LocationManager
    @AppStorage("mapKind") private var mapKind = 0
    @State private var camera: MapCameraPosition = .userLocation(fallback: .automatic)
    @State private var showMatch = false
    @State private var showSettings = false

    var body: some View {
        ZStack {
            mapLayer
            overlayLayer
        }
        .onAppear {
            if location.authorization == .notDetermined {
                location.requestWhenInUse()
            }
        }
        .sheet(isPresented: $showMatch) {
            MatchSheet()
                .environmentObject(store)
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(location)
        }
    }

    private var mapStyleValue: MapStyle {
        mapKind == 0 ? .standard : .hybrid
    }

    private var mapLayer: some View {
        Map(position: $camera) {
            UserAnnotation()
            ForEach(store.places) { place in
                MapCircle(center: place.coordinate, radius: place.radius)
                    .foregroundStyle(Theme.lime.opacity(0.3))
            }
            ForEach(store.places) { place in
                Annotation(place.name, coordinate: place.coordinate) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.title)
                        .foregroundStyle(Theme.limeDeep)
                }
            }
        }
        .mapStyle(mapStyleValue)
        .ignoresSafeArea(edges: .top)
    }

    private var overlayLayer: some View {
        VStack {
            HStack {
                Spacer()
                Button {
                    showSettings = true
                } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(Color.white)
                        .frame(width: 42, height: 42)
                        .background(Theme.ink, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                }
            }
            .padding(.horizontal, 16)

            Spacer()

            HStack {
                Button {
                    camera = .userLocation(fallback: .automatic)
                } label: {
                    Image(systemName: "location.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(Theme.ink)
                        .frame(width: 42, height: 42)
                        .background(Color.white, in: Circle())
                        .shadow(color: Color.black.opacity(0.15), radius: 4, y: 1)
                }
                Spacer()
            }
            .padding(.horizontal, 16)

            matchBanner
        }
        .padding(.top, 8)
    }

    private var matchBanner: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text("快去匹配另一半")
                    .font(.subheadline.weight(.semibold))
                Text("开启甜蜜之旅吧!")
                    .font(.caption)
                    .opacity(0.7)
            }
            .foregroundStyle(Color.white)
            Spacer()
            Button {
                showMatch = true
            } label: {
                Text("去匹配")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(Theme.ink)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Theme.lime, in: Capsule())
            }
        }
        .padding(14)
        .background(Theme.ink, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .padding(.horizontal, 12)
        .padding(.bottom, 8)
    }
}
